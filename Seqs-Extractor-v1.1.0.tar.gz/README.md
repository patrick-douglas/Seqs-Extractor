# Seqs-Extractor
![logo](https://github.com/patrick-douglas/Seqs-Extractor/blob/master/logo/seqs-extractor_icon2.png)
								
**Support, feedback or questions to patrick@ufpa.br**

Version 1.0.0 (Oct 13, 2017) By Patrick Douglas email: patrick@ufpa.br 

### To view all intructions about usage and instalation please visit 
[Seqs-Extractor home page](https://github.com/patrick-douglas/Seqs-Extractor/wiki)
